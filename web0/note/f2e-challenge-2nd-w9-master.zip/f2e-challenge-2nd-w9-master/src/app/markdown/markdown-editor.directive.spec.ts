import { MarkdownEditorDirective } from './markdown-editor.directive';

describe('MarkdownEditorDirective', () => {
  it('should create an instance', () => {
    const directive = new MarkdownEditorDirective();
    expect(directive).toBeTruthy();
  });
});
