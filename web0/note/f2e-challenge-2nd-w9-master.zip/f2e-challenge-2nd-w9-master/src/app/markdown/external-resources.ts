export const SimpleMDEJS = 'https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.js';
export const SimpleMDECSS = 'https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.css';
